
import unittest
from app.modules.data_loader import load_data

class TestDataLoader(unittest.TestCase):
    def test_load_data(self):
        # Test data loading
        pass
