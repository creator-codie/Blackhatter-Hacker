
import os

def get_config():
    return {
        'data_path': os.getenv('DATA_PATH', 'data/enhanced_iter3_response_data.csv'),
        'log_path': os.getenv('LOG_PATH', 'logs/app.log')
    }
