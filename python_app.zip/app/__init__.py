# Initialize the application package
