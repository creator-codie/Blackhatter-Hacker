
import pandas as pd

def load_data(data_path):
    try:
        data = pd.read_csv(data_path)
        return data
    except Exception as e:
        logging.error(f"Error loading data: {e}")
        return None
