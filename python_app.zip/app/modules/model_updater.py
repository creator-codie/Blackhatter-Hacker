
import logging

def update_model(data, config):
    if data is not None:
        logging.info("Model update started.")
        # Simulate model update
        logging.info("Model update completed.")
    else:
        logging.error("Model update failed due to no data.")
