
import logging

def initialize_logging(config):
    logging.basicConfig(filename=config['log_path'], level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    logging.info('Logging initialized.')
