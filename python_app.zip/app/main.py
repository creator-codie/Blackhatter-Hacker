
from app.config import get_config
from app.utils import initialize_logging
from app.modules import data_loader, model_updater

def main():
    config = get_config()
    initialize_logging(config)
    data = data_loader.load_data(config['data_path'])
    model_updater.update_model(data, config)

if __name__ == "__main__":
    main()
